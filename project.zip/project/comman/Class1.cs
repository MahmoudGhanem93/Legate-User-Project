﻿using System;

namespace comman
{
    public class Class1
    {
    }
}
