﻿using Application.Users.Commands.Create;
using Application.Users.Commands.Delete;
using Application.Users.Commands.Update;
using Application.Users.Queries.GetUserDetail;
using Application.Users.Queries.GetUserList;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace WebApi.Controllers
{
    public class UserController : BaseController
    {
       
        [HttpGet]
        public async Task<ActionResult<UserDto>> GetAll()
        {
            return Ok(await Mediator.Send(new GetUserListQuery()));
        }
        [HttpGet("id")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<GetUserDetailVm>> Get(int id)
        {
            return Ok(await Mediator.Send(new GetUserDetailQuery { Id = id }));
        } 
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> AddUser([FromBody]CreateUserCommand userCommand)
        {
            var UserId = await Mediator.Send(userCommand);

            return Ok(UserId);

            //await Mediator.Send(userCommand);
            //return NoContent();
        }
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Update([FromBody]UpdateUserCommand userCommand)
        {
            await Mediator.Send(userCommand);
            return NoContent();
        }
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Delete(int id)
        {
           await Mediator.Send(new DeleteUserCommand {Id=id });
            return NoContent();
        }


    }
}
