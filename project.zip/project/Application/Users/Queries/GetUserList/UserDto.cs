﻿using Application.comman.Mapping;
using AutoMapper;
using Domian.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Users.Queries.GetUserList
{
    public class UserDto : IMapFrom<User>
    {
        public int Id { set; get; }
        public string Name { set; get; }
        public string Address { set; get; }
        public void Mapping(Profile profile)
        {
            profile.CreateMap<User, UserDto>();
        }


    }
}
