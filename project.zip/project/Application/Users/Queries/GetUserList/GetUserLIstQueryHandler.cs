﻿using Application.comman.interfaces;
using AutoMapper;
using MediatR;
using AutoMapper.QueryableExtensions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Application.Users.Queries.GetUserList
{
    public class GetUsersListQueryHandler : IRequestHandler<GetUserListQuery, UsersListVm>
    {
        private readonly IUserDbContext context;
        private readonly IMapper mapper;
        public GetUsersListQueryHandler(IUserDbContext _Context, IMapper _mapper)
        {
            context =_Context;
            mapper = _mapper;
        }
        public async Task<UsersListVm> Handle(GetUserListQuery request, CancellationToken cancellationToken)
        {
            var users = await context.Users.ProjectTo<UserDto>(mapper.ConfigurationProvider)
                .ToListAsync(cancellationToken);
            var userVM = new UsersListVm
            {
                Users = users
            };
            return userVM;
        }

    }
}
