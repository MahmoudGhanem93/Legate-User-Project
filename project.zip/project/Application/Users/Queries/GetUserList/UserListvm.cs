﻿using AutoMapper;
using Domian.Entities;
using System.Collections.Generic;

namespace Application.Users.Queries.GetUserList
{
    public class UsersListVm
    {
        public IList<UserDto> Users { set; get; }
    }
}
