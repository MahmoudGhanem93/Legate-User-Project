﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Users.Queries.GetUserDetail
{
    public class GetUserDetailQuery : IRequest<GetUserDetailVm>
    {
        public int Id { set; get; }
    }
}
