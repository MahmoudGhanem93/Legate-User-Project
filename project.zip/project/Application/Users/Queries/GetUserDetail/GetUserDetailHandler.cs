﻿using Application.comman.Exceptions;
using Application.comman.interfaces;
using AutoMapper;
using Domian.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Users.Queries.GetUserDetail
{
    public class GetUserDetailHandler : IRequestHandler<GetUserDetailQuery, GetUserDetailVm>
    {
        private readonly IUserDbContext context;
        private readonly IMapper mapper;
        public GetUserDetailHandler(IUserDbContext _context, IMapper _mapper)
        {
            context = _context;
            mapper = _mapper;
        }
        public async Task<GetUserDetailVm> Handle(GetUserDetailQuery request, CancellationToken cancellationToken)
        {
            var user = await context.Users.Where(a => a.Id == request.Id).FirstOrDefaultAsync();
            if (user == null)
            {
                throw new NotFoundException(nameof(User), request.Id);
            }
            return mapper.Map<GetUserDetailVm>(user);

        }
    }
}
