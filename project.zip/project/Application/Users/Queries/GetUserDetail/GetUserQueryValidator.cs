﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Users.Queries.GetUserDetail
{
    class GetUserQueryValidator : AbstractValidator<GetUserDetailQuery>
    {
        public GetUserQueryValidator()
        {
            RuleFor(v => v.Id).NotEmpty();
        }
    }
}
