﻿using Application.comman.Exceptions;
using Application.comman.interfaces;
using AutoMapper;
using Domian.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Users.Commands.Update
{
    class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand>
    {
        private readonly IUserDbContext context;
        private readonly IMapper mapper;
        public UpdateUserCommandHandler(IUserDbContext _context, IMapper _mapper)
        {
            context = _context;
            mapper = _mapper;
        }
        public async Task<Unit> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            var entity = await context.Users.SingleOrDefaultAsync(a => a.Id == request.Id, cancellationToken);
            if (entity == null)
            {
                throw new NotFoundException(nameof(User), request.Id);
            }
            entity.Address = request.Address;
            entity.Name = request.Name;
            entity.Age = request.Age;
            entity.JoiningDate = request.JoiningDate;
            entity.Phone = request.Phone;
            entity.Postion = request.Postion;
            entity.salary = request.salary;
            context.Users.Update(entity);
            await context.SaveChangesAsync(cancellationToken);
            return Unit.Value;
        }
    }
}
