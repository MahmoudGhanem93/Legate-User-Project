﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Users.Commands.Delete
{
    public class DeleteCommandValidator : AbstractValidator<DeleteUserCommand>
    {
        public DeleteCommandValidator()
        {
            RuleFor(v => v.Id).NotEmpty();
        }
    }
}
