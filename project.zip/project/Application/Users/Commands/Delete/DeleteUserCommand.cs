﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Users.Commands.Delete
{
    public class DeleteUserCommand : IRequest
    {
        public int Id { set; get; }
    }
}
