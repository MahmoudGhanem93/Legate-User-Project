﻿using Application.comman.interfaces;
using AutoMapper;
using Domian.Entities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Users.Commands.Create
{
    public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, int>
    {
        private readonly IUserDbContext context;
        private readonly IMapper mapper;
        public CreateUserCommandHandler(IUserDbContext _context, IMapper _mapper)
        {
            context = _context;
            mapper = _mapper;
        }
        public async Task<int> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            var entity = new User()
            {
                //Id = request.Id,
                Name = request.Name,
                Address = request.Address,
                Age = request.Age,
                salary = request.salary,
                Postion = request.Postion,
                JoiningDate = request.JoiningDate,
                Phone = request.Phone,
            };
            context.Users.Add(entity);
            await context.SaveChangesAsync(cancellationToken);
            return entity.Id;
        }
    }
}
