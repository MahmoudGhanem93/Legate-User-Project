﻿
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;
using Domian.Entities;



namespace Application.comman.interfaces
{
    public interface IUserDbContext
    {
        DbSet<User> Users { get; set; }
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}
