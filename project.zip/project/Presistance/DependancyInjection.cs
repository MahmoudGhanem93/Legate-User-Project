﻿using Application.comman.interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;


namespace Presistance
{
    public static class DependancyInjection
    {
        public static IServiceCollection AddPersistance(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<UserDBContext>(options => options.UseSqlServer(configuration.GetConnectionString("sqlConnection"), b => b.MigrationsAssembly("Persistence")));
            services.AddScoped<IUserDbContext>(provider => provider.GetService<UserDBContext>());
            return services;
        }
    }
}
