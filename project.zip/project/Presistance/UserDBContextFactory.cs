﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Presistance
{
    public class UserDBContextFactory : DesignTimeDbContextFactoryBase<UserDBContext>
    {
        protected override UserDBContext CreateNewInstance(DbContextOptions<UserDBContext> options)
        {
            return new UserDBContext(options);
        }
    }
}
